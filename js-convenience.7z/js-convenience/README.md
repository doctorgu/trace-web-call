# Convenience of Javascript
For easy coding life
